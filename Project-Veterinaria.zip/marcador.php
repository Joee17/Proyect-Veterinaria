<?php 
session_start();
if(!isset($_SESSION["usuario"])||$_SESSION['idtipo']==4||$_SESSION['idtipo']==6) {
	header('Location: index.php');
}


?>
<!DOCTYPE html>
<html lang="ES-es">
<head>
<?php
  require_once("head.php")
  ?>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        
       
        <style>
             #inicio_m{
    padding: 7px 87px;
    margin: 22px;
        }
         #inicio_t{
    padding: 7px 87px;
    margin: 22px;
        }
         #fin_m{
    padding: 7px 87px;
    margin: 22px;
        }
        #fin_t{
    padding: 7px 87px;
    margin: 22px;
        }
        @media (min-width: 360px) {
        #inicio_m{
    padding: 7px 87px;
    margin: 22px;
        }
         #inicio_t{
    padding: 7px 87px;
    margin: 22px;
        }
         #fin_m{
    padding: 7px 93px;
    margin: 22px;
        }
        #fin_t{
    padding: 7px 93px;
    margin: 22px;
        }
        }
 @media (min-width: 410px) {
          #inicio_m{
    padding: 7px 87px;
    margin: 22px;
        }
         #inicio_t{
    padding: 5px 87px;
    margin: 22px;
        }
         #fin_m{
    padding: 7px 93px;
    margin: 22px;
        }
        #fin_t{
    padding: 7px 93px;
    margin: 22px;
        }
}
        </style>
</head>

<?php
  require_once("menu.php")
  ?>
  
  <div class="content-wrapper" id="client11111">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Veterinaria </a></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  </div>
   
  <?php
  require_once("footer.php")
  ?>